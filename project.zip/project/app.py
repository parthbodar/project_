import torch
import cv2
from deep_sort_realtime.deepsort_tracker import DeepSort
import numpy as np

# Initialize YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Initialize DeepSort tracker
tracker = DeepSort(max_age=30, n_init=3, nms_max_overlap=1.0, max_cosine_distance=0.2, nn_budget=100)


# Example classify_person function (replace with your actual classifier)
def classify_person(image):
    # Resize the image to a fixed size (example: 224x224) and preprocess
    resized_img = cv2.resize(image, (224, 224))

    # Convert the image to a tensor and normalize (example preprocessing)
    tensor_img = torch.from_numpy(resized_img).permute(2, 0, 1).float() / 255.0
    tensor_img = tensor_img.unsqueeze(0)  # Add batch dimension

    # Mock classification: replace with your model inference
    # For demonstration, randomly classify as 'child' or 'adult'
    label = 'child' if np.random.rand() > 0.5 else 'adult'

    return label


def detect_and_track(frame):
    # Detect persons using YOLOv5
    results = model(frame)
    bboxes = results.xyxy[0][:, :4].cpu().numpy()  # Bounding boxes
    confidences = results.xyxy[0][:, 4].cpu().numpy()  # Confidence scores
    class_ids = results.xyxy[0][:, 5].cpu().numpy()  # Class IDs (person)

    detections = []
    for bbox, confidence, class_id in zip(bboxes, confidences, class_ids):
        if int(class_id) == 0:  # Class ID 0 corresponds to 'person' in YOLOv5
            x1, y1, x2, y2 = bbox
            detections.append(([x1, y1, x2 - x1, y2 - y1], confidence, class_id))

    # Update tracker with detections
    tracks = tracker.update_tracks(detections, frame=frame)

    for track in tracks:
        if not track.is_confirmed() or track.time_since_update > 1:
            continue

        track_id = track.track_id
        bbox = track.to_ltrb()  # Get bounding box in left, top, right, bottom format

        x1, y1, x2, y2 = map(int, bbox)
        person_img = frame[y1:y2, x1:x2]

        # Classify as child or adult
        person_type = classify_person(person_img)  # Returns 'child' or 'adult'

        # Draw bounding box and label on the frame
        label = f'ID {track_id}: {person_type}'
        cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
        cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    return frame


# Video processing loop
cap = cv2.VideoCapture('E:\\cv\\pythonProject\\Speech Therapy Training Session- Moderate to Severe Autism.mp4')
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = detect_and_track(frame)

    # Display the frame with detections
    cv2.imshow('Object Recognition and Tracking', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
