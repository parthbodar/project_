# Object Detection and Tracking with YOLOv5 and DeepSort

This project demonstrates the use of YOLOv5 for object detection and DeepSort for tracking objects across video frames. The focus is on detecting persons, classifying them as "child" or "adult," and tracking them in a video feed.

## Project Overview

The code processes a video file, detects persons in each frame using YOLOv5, and tracks these persons across multiple frames using DeepSort. Additionally, each detected person is classified as either a "child" or "adult" based on a simple mock classifier.

### Key Components

1. **YOLOv5**: A state-of-the-art object detection model that identifies objects in images or video frames. In this project, we use YOLOv5 to detect persons in each frame.

2. **DeepSort**: A tracking algorithm that associates detected objects across frames, giving each tracked object a unique ID.

3. **Person Classification**: A mock classifier that randomly classifies detected persons as "child" or "adult."

## Workflow

1. **Initialize YOLOv5 Model**:
   The YOLOv5 model is loaded using the `torch.hub.load` function, with the model weights pre-trained on the COCO dataset.

   ```python
   model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
